import { useEffect, useRef } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { GameCanvas } from '../lib/game/canvas';
import { CANVAS_HEIGHT, CANVAS_WIDTH } from '../lib/game/constants';

export default function Game() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<GameCanvas | null>(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    const game = new GameCanvas(canvasRef.current);
    gameRef.current = game;

    return () => {
      game.stop();
    };
  }, []);

  const handleStart = () => {
    if (gameRef.current) {
      gameRef.current.startGame();
    }
  };

  const handleRestart = () => {
    if (gameRef.current) {
      gameRef.current.restartGame();
    }
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background p-4">
      <Card className="p-4">
        <canvas 
          ref={canvasRef}
          width={CANVAS_WIDTH}
          height={CANVAS_HEIGHT}
          className="border border-border rounded-lg"
        />
        <div className="mt-4 flex justify-center gap-4">
          <Button onClick={handleStart}>Start Game</Button>
          <Button onClick={handleRestart} variant="outline">Restart</Button>
        </div>
        <div className="mt-4 text-sm text-muted-foreground text-center">
          <p>Use arrow keys to move</p>
          <p>SPACE for spin move</p>
          <p>SHIFT for stiff arm</p>
        </div>
      </Card>
    </div>
  );
}