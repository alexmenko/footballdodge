export class Controls {
  public up: boolean = false;
  public down: boolean = false;
  public left: boolean = false;
  public right: boolean = false;
  public space: boolean = false;
  public shift: boolean = false;
  public digit1: boolean = false;
  public digit2: boolean = false;
  public digit3: boolean = false;
  private spaceKeyCallback: () => void;

  constructor(spaceKeyCallback: () => void) {
    this.spaceKeyCallback = spaceKeyCallback;
    window.addEventListener('keydown', this.handleKeyDown);
    window.addEventListener('keyup', this.handleKeyUp);
  }

  private handleKeyDown = (e: KeyboardEvent) => {
    e.preventDefault(); // Prevent default scrolling behavior
    switch (e.key) {
      case 'ArrowUp':
        this.up = true;
        break;
      case 'ArrowDown':
        this.down = true;
        break;
      case 'ArrowLeft':
        this.left = true;
        break;
      case 'ArrowRight':
        this.right = true;
        break;
      case ' ':
        this.space = true;
        this.spaceKeyCallback(); // Call the callback for game restart
        break;
      case 'Shift':
        this.shift = true;
        break;
      case '1':
        this.digit1 = true;
        break;
      case '2':
        this.digit2 = true;
        break;
      case '3':
        this.digit3 = true;
        break;
    }
  };

  private handleKeyUp = (e: KeyboardEvent) => {
    switch (e.key) {
      case 'ArrowUp':
        this.up = false;
        break;
      case 'ArrowDown':
        this.down = false;
        break;
      case 'ArrowLeft':
        this.left = false;
        break;
      case 'ArrowRight':
        this.right = false;
        break;
      case ' ':
        this.space = false;
        break;
      case 'Shift':
        this.shift = false;
        break;
      case '1':
        this.digit1 = false;
        break;
      case '2':
        this.digit2 = false;
        break;
      case '3':
        this.digit3 = false;
        break;
    }
  };

  public cleanup() {
    window.removeEventListener('keydown', this.handleKeyDown);
    window.removeEventListener('keyup', this.handleKeyUp);
  }
}