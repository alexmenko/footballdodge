import { CANVAS_WIDTH, CANVAS_HEIGHT } from './constants';

export class GameState {
  public currentLevel: number = 1;
  public score: number = 0;
  public isPlaying: boolean = false;
  public hasStarted: boolean = false;
  public isKickoff: boolean = false;
  public hasCaughtBall: boolean = false;
  public powerUp: 'freeze' | 'strength' | 'speed' | null = null;
  public powerUpDuration: number = 0;
  public isReplay: boolean = false;
  public replayPath: Array<{x: number, y: number}> = [];
  public defenderPaths: Array<Array<{x: number, y: number}>> = [];
  public replayIndex: number = 0;
  public kickoffPosition = { x: 0, y: 0 };
  public powerUps: Array<{
    type: 'freeze' | 'strength' | 'speed',
    x: number,
    y: number,
    active: boolean
  }> = [];

  private spawnPowerUp() {
    const validTypes: ('freeze' | 'strength' | 'speed')[] = [];
    if (this.currentLevel >= 3) validTypes.push('freeze');
    if (this.currentLevel >= 5) validTypes.push('strength');
    if (this.currentLevel >= 7) validTypes.push('speed');

    if (validTypes.length === 0) return;

    // 20% chance to spawn a power-up
    if (Math.random() > 0.2) return;

    const type = validTypes[Math.floor(Math.random() * validTypes.length)];
    const margin = 50;

    this.powerUps.push({
      type,
      x: margin + Math.random() * (800 - 2 * margin),
      y: margin + Math.random() * (400 - 2 * margin),
      active: true
    });
  }

  public renderGameOver(ctx: CanvasRenderingContext2D) {
    ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    ctx.fillStyle = 'white';
    ctx.font = '48px Arial';
    ctx.textAlign = 'center';

    if (!this.hasStarted) {
      ctx.fillText('Football Rush', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 - 50);
      ctx.font = '24px Arial';
      ctx.fillText('Click Start to Play!', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 + 20);
    } else {
      ctx.fillText('You got run over. Game Over!', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 - 20);
      ctx.font = '24px Arial';
      ctx.fillText(
        `Final Score: ${this.score}`,
        CANVAS_WIDTH / 2,
        CANVAS_HEIGHT / 2 + 20
      );
      ctx.fillText(
        'Press SPACE to Restart',
        CANVAS_WIDTH / 2,
        CANVAS_HEIGHT / 2 + 60
      );
    }
  }

  public startGame() {
    this.currentLevel = 1;
    this.score = 0;
    this.isPlaying = true;
    this.hasStarted = true;
    this.powerUp = null;
    this.powerUpDuration = 0;
    this.resetKickoffPosition();
    this.startKickoff();
  }

  public startKickoff() {
    this.isKickoff = true;
    this.hasCaughtBall = false;
    this.resetKickoffPosition();
    this.replayPath = [];
    this.defenderPaths = [];
    this.powerUps = [];
    this.spawnPowerUp();
  }

  public resetKickoffPosition() {
    const centerX = 400;
    const variance = 100;
    this.kickoffPosition = {
      x: centerX + (Math.random() * variance * 2 - variance),
      y: 500
    };
  }

  public catchBall() {
    this.hasCaughtBall = true;
    this.isKickoff = false;
  }

  public startReplay() {
    this.isReplay = true;
    this.replayIndex = 0;
  }

  public stopReplay() {
    this.isReplay = false;
    this.startKickoff();
  }

  public recordPosition(x: number, y: number, defenderPositions: Array<{x: number, y: number}>) {
    if (this.hasCaughtBall && !this.isReplay) {
      this.replayPath.push({x, y});
      this.defenderPaths.push(defenderPositions);
    }
  }

  public completeLevel() {
    this.score += this.currentLevel * 100;
    this.currentLevel++;
    this.startReplay();
  }

  public endGame() {
    this.isPlaying = false;
    this.powerUp = null;
    this.powerUpDuration = 0;
  }

  public restartGame() {
    this.startGame();
  }

  public checkPowerUpCollision(playerX: number, playerY: number, playerSize: number): boolean {
    const collision = this.powerUps.find(powerUp => {
      if (!powerUp.active) return false;

      const dx = playerX + playerSize/2 - powerUp.x;
      const dy = playerY + playerSize/2 - powerUp.y;
      const distance = Math.sqrt(dx * dx + dy * dy);
      return distance < 30;
    });

    if (collision) {
      collision.active = false;
      this.powerUp = collision.type;
      this.powerUpDuration = 300;
      return true;
    }
    return false;
  }

  public updatePowerUp() {
    if (this.powerUpDuration > 0) {
      this.powerUpDuration--;
      if (this.powerUpDuration === 0) {
        this.powerUp = null;
      }
    }
  }
}