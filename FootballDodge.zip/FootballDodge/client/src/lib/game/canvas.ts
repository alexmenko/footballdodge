import { Player } from './player';
import { Defender } from './defender';
import { Field } from './field';
import { GameState } from './gameState';
import { CANVAS_WIDTH, CANVAS_HEIGHT, PLAYER_SIZE } from './constants';
import { Controls } from './controls';

export class GameCanvas {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private animationId: number = 0;
  private field: Field;
  private player: Player;
  private defenders: Defender[] = [];
  private gameState: GameState;
  private controls: Controls | null = null;
  private replaySpeed: number = 2;
  private lastFrameTime: number = 0;
  private readonly targetFPS: number = 60;
  private readonly frameInterval: number = 1000 / 60;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const context = canvas.getContext('2d');
    if (!context) throw new Error('Could not get canvas context');
    this.ctx = context;

    this.field = new Field(this.ctx);
    this.player = new Player(this.ctx);
    this.gameState = new GameState();

    this.render();
  }

  public startGame() {
    this.gameState.startGame();
    this.controls = new Controls(this.handleSpaceKey.bind(this));
    this.initializeLevel();
    this.lastFrameTime = 0;
    this.start();
  }

  private handleSpaceKey() {
    if (!this.gameState.isPlaying && this.gameState.hasStarted) {
      this.restartGame();
    }
  }

  public restartGame() {
    if (this.controls) {
      this.controls.cleanup();
    }
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
      this.animationId = 0;
    }
    this.lastFrameTime = 0;
    this.startGame();
  }

  private initializeLevel() {
    this.defenders = [];
    const defenderCount = this.gameState.currentLevel + 2;

    for (let i = 0; i < defenderCount; i++) {
      this.defenders.push(new Defender(
        this.ctx,
        Math.random() * (CANVAS_WIDTH - 40) + 20,
        Math.random() * (CANVAS_HEIGHT / 2) + CANVAS_HEIGHT / 4,
        i,
        defenderCount
      ));
    }

    this.player.reset();
  }

  private update() {
    if (!this.controls) return;

    if (this.gameState.isReplay) {
      if (this.gameState.replayIndex < this.gameState.replayPath.length) {
        const pos = this.gameState.replayPath[this.gameState.replayIndex];
        const defenderPositions = this.gameState.defenderPaths[this.gameState.replayIndex] || [];

        this.player.setPosition(pos.x, pos.y);

        this.defenders.forEach((defender, index) => {
          if (defenderPositions[index]) {
            defender.setPosition(defenderPositions[index].x, defenderPositions[index].y);
          }
        });

        this.gameState.replayIndex += this.replaySpeed;
      } else {
        this.gameState.stopReplay();
        this.initializeLevel();
      }
      return;
    }

    if (this.gameState.powerUpDuration > 0) {
      this.gameState.updatePowerUp();
    }

    if (this.gameState.powerUp === 'speed') {
      this.player.setSpeedBoost(2);
    } else {
      this.player.setSpeedBoost(1);
    }

    this.player.update(this.controls);

    const playerPos = this.player.getPosition();
    const defenderPositions = this.defenders.map(d => d.getPosition());
    this.gameState.recordPosition(playerPos.x, playerPos.y, defenderPositions);

    // Check for power-up collection
    this.gameState.checkPowerUpCollision(playerPos.x, playerPos.y, PLAYER_SIZE);

    if (this.gameState.isKickoff && !this.gameState.hasCaughtBall) {
      if (this.player.canCatchBall(this.gameState.kickoffPosition)) {
        this.gameState.catchBall();
        this.player.catchBall();
      }
    }

    if (this.gameState.hasCaughtBall && this.gameState.powerUp !== 'freeze') {
      for (const defender of this.defenders) {
        defender.update(this.player);

        if (defender.collidesWith(this.player)) {
          const canOverpower = this.gameState.powerUp === 'strength' &&
            this.player.getOverpoweredDefenders() < 2;

          if (canOverpower) {
            defender.disable();
            this.player.incrementOverpoweredDefenders();
          } else {
            this.gameState.endGame();
            return; // Stop processing immediately after collision
          }
        }
      }
    }

    if (this.player.hasReachedEndzone()) {
      this.gameState.completeLevel();
      this.initializeLevel();
    }
  }

  private render() {
    this.ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
    this.field.draw();

    if (this.gameState.hasStarted) {
      // Draw power-ups
      this.gameState.powerUps.forEach(powerUp => {
        if (!powerUp.active) return;

        this.ctx.save();

        // Draw glowing circle
        const gradient = this.ctx.createRadialGradient(
          powerUp.x, powerUp.y, 0,
          powerUp.x, powerUp.y, 30
        );

        let color;
        switch (powerUp.type) {
          case 'freeze':
            color = '#00ffff';
            break;
          case 'strength':
            color = '#ff0000';
            break;
          case 'speed':
            color = '#ffff00';
            break;
        }

        gradient.addColorStop(0, color);
        gradient.addColorStop(1, 'rgba(255, 255, 255, 0)');

        this.ctx.fillStyle = gradient;
        this.ctx.beginPath();
        this.ctx.arc(powerUp.x, powerUp.y, 30, 0, Math.PI * 2);
        this.ctx.fill();

        // Draw icon
        this.ctx.fillStyle = 'white';
        this.ctx.font = 'bold 20px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.textBaseline = 'middle';

        let symbol;
        switch (powerUp.type) {
          case 'freeze':
            symbol = '❄';
            break;
          case 'strength':
            symbol = '💪';
            break;
          case 'speed':
            symbol = '⚡';
            break;
        }

        this.ctx.fillText(symbol, powerUp.x, powerUp.y);
        this.ctx.restore();
      });

      if (this.gameState.isReplay) {
        this.ctx.beginPath();
        this.ctx.strokeStyle = 'rgba(255, 255, 0, 0.5)';
        this.ctx.lineWidth = 3;
        const path = this.gameState.replayPath.slice(0, this.gameState.replayIndex);
        if (path.length > 0) {
          this.ctx.moveTo(path[0].x + PLAYER_SIZE / 2, path[0].y + PLAYER_SIZE / 2);
          for (const pos of path.slice(1)) {
            this.ctx.lineTo(pos.x + PLAYER_SIZE / 2, pos.y + PLAYER_SIZE / 2);
          }
        }
        this.ctx.stroke();

        this.defenders.forEach((_, defenderIndex) => {
          this.ctx.beginPath();
          this.ctx.strokeStyle = 'rgba(21, 101, 192, 0.3)';
          const defenderPath = this.gameState.defenderPaths
            .slice(0, this.gameState.replayIndex)
            .map(frame => frame[defenderIndex])
            .filter(pos => pos);

          if (defenderPath.length > 0) {
            this.ctx.moveTo(defenderPath[0].x + PLAYER_SIZE / 2, defenderPath[0].y + PLAYER_SIZE / 2);
            for (const pos of defenderPath.slice(1)) {
              this.ctx.lineTo(pos.x + PLAYER_SIZE / 2, pos.y + PLAYER_SIZE / 2);
            }
          }
          this.ctx.stroke();
        });

        this.ctx.fillStyle = 'rgba(255, 255, 0, 0.7)';
        this.ctx.fillRect(CANVAS_WIDTH - 150, 60, 140, 40);
        this.ctx.fillStyle = 'black';
        this.ctx.font = 'bold 24px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText('REPLAY!', CANVAS_WIDTH - 80, 85);
      }

      // Draw score panel with semi-transparent background
      this.ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
      this.ctx.fillRect(10, 10, 200, 120);

      this.ctx.fillStyle = 'white';
      this.ctx.font = 'bold 24px Arial';
      this.ctx.textAlign = 'left';
      this.ctx.fillText(`Level: ${this.gameState.currentLevel}`, 20, 40);
      this.ctx.fillText(`Score: ${this.gameState.score}`, 20, 70);


      if (this.gameState.powerUp) {
        this.ctx.fillStyle = 'rgba(255, 255, 0, 0.7)';
        this.ctx.fillRect(CANVAS_WIDTH - 150, 10, 140, 40);
        this.ctx.fillStyle = 'black';
        this.ctx.font = 'bold 16px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText(
          `${this.gameState.powerUp.toUpperCase()}!`,
          CANVAS_WIDTH - 80,
          35
        );
      }

      if (this.gameState.isKickoff && !this.gameState.hasCaughtBall) {
        this.ctx.fillStyle = 'rgba(255, 255, 0, 0.3)';
        this.ctx.beginPath();
        this.ctx.arc(
          this.gameState.kickoffPosition.x,
          this.gameState.kickoffPosition.y,
          40,
          0,
          Math.PI * 2
        );
        this.ctx.fill();

        this.ctx.fillStyle = 'white';
        this.ctx.font = '16px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText('Catch the ball!', this.gameState.kickoffPosition.x, this.gameState.kickoffPosition.y - 30);
      }

      for (const defender of this.defenders) {
        defender.draw();
      }
      this.player.draw();
    } else {
      this.gameState.renderGameOver(this.ctx);
    }
  }

  private gameLoop = (timestamp: number) => {
    if (!this.lastFrameTime) {
      this.lastFrameTime = timestamp;
    }

    const elapsed = timestamp - this.lastFrameTime;

    if (elapsed >= this.frameInterval) {
      if (this.gameState.isPlaying) {
        this.update();
      }
      this.render();
      this.lastFrameTime = timestamp - (elapsed % this.frameInterval);
    }

    this.animationId = requestAnimationFrame(this.gameLoop);
  };

  public start() {
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
    }
    this.lastFrameTime = 0;
    this.animationId = requestAnimationFrame(this.gameLoop);
  }

  public stop() {
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
      this.animationId = 0;
    }
    if (this.controls) {
      this.controls.cleanup();
    }
  }
}