import { Player } from './player';
import { PLAYER_SIZE, CANVAS_WIDTH, CANVAS_HEIGHT } from './constants';

export class Defender {
  private x: number;
  private y: number;
  private speed: number = 3.5; // Increased base speed significantly
  private ctx: CanvasRenderingContext2D;
  private disabled: boolean = false;
  private playerNumber: number;
  private zoneX: number;
  private zoneY: number;
  private zoneWidth: number;
  private zoneHeight: number;
  private defenderIndex: number;
  private totalDefenders: number;
  private lastPlayerX: number = 0;
  private lastPlayerY: number = 0;

  constructor(ctx: CanvasRenderingContext2D, x: number, y: number, index: number, total: number) {
    this.ctx = ctx;
    this.x = x;
    this.y = y;
    this.playerNumber = Math.floor(Math.random() * 89) + 10;
    this.defenderIndex = index;
    this.totalDefenders = total;
    this.assignZone();
  }

  private assignZone() {
    const columns = Math.ceil(Math.sqrt(this.totalDefenders));
    const rows = Math.ceil(this.totalDefenders / columns);

    this.zoneWidth = (CANVAS_WIDTH - 100) / columns;
    this.zoneHeight = (CANVAS_HEIGHT - 200) / rows;

    const zoneColumn = this.defenderIndex % columns;
    const zoneRow = Math.floor(this.defenderIndex / columns);

    this.zoneX = 50 + (zoneColumn * this.zoneWidth) + (this.zoneWidth / 2);
    this.zoneY = 100 + (zoneRow * this.zoneHeight) + (this.zoneHeight / 2);
  }

  private isPlayerInZone(playerX: number, playerY: number): boolean {
    const zoneMinX = this.zoneX - this.zoneWidth / 2;
    const zoneMaxX = this.zoneX + this.zoneWidth / 2;
    const zoneMinY = this.zoneY - this.zoneHeight / 2;
    const zoneMaxY = this.zoneY + this.zoneHeight / 2;

    return playerX >= zoneMinX && playerX <= zoneMaxX && 
           playerY >= zoneMinY && playerY <= zoneMaxY;
  }

  private calculateInterceptPoint(playerX: number, playerY: number): { x: number, y: number } {
    const playerDX = playerX - this.lastPlayerX;
    const playerDY = playerY - this.lastPlayerY;

    if (Math.abs(playerDX) < 0.1 && Math.abs(playerDY) < 0.1) {
      return { x: playerX, y: playerY };
    }

    // Increased look-ahead distance for better interception
    const lookAhead = 40;
    const predictedX = playerX + (playerDX * lookAhead);
    const predictedY = playerY + (playerDY * lookAhead);

    // Calculate a point between current player position and predicted position
    // This helps defenders stay closer to the actual player while still anticipating movement
    return {
      x: playerX + (predictedX - playerX) * 0.6,
      y: playerY + (predictedY - playerY) * 0.6
    };
  }

  public update(player: Player) {
    if (this.disabled) return;

    const playerPos = player.getPosition();
    const dx = playerPos.x - this.x;
    const dy = playerPos.y - this.y;
    const distanceToPlayer = Math.sqrt(dx * dx + dy * dy);

    const intercept = this.calculateInterceptPoint(playerPos.x, playerPos.y);
    const dxIntercept = intercept.x - this.x;
    const dyIntercept = intercept.y - this.y;
    const distanceToIntercept = Math.sqrt(dxIntercept * dxIntercept + dyIntercept * dyIntercept);

    // Always pursue the player more aggressively when they have the ball
    const pursuitSpeed = this.speed * (distanceToPlayer < 80 ? 1.3 : 1.1);

    // Direct pursuit with position prediction
    if (distanceToPlayer < 200) {
      this.x += (dxIntercept / distanceToIntercept) * pursuitSpeed;
      this.y += (dyIntercept / distanceToIntercept) * pursuitSpeed;
    } 
    // Strategic positioning to cut off player's path
    else {
      const cutoffX = this.zoneX + (intercept.x - this.zoneX) * 0.7;
      const cutoffY = this.zoneY + (intercept.y - this.zoneY) * 0.7;

      const dxCutoff = cutoffX - this.x;
      const dyCutoff = cutoffY - this.y;
      const distanceToCutoff = Math.sqrt(dxCutoff * dxCutoff + dyCutoff * dyCutoff);

      this.x += (dxCutoff / distanceToCutoff) * this.speed;
      this.y += (dyCutoff / distanceToCutoff) * this.speed;
    }

    // Keep defender in bounds
    this.x = Math.max(0, Math.min(this.x, CANVAS_WIDTH - PLAYER_SIZE));
    this.y = Math.max(0, Math.min(this.y, CANVAS_HEIGHT - PLAYER_SIZE));

    // Update last known player position
    this.lastPlayerX = playerPos.x;
    this.lastPlayerY = playerPos.y;
  }

  public draw() {
    if (this.disabled) return;
    this.drawDefender();
  }

  private drawDefender() {
    this.ctx.save();

    // Draw body (jersey)
    this.ctx.fillStyle = '#1565C0'; // Blue for defense
    this.ctx.beginPath();
    this.ctx.ellipse(
      this.x + PLAYER_SIZE/2,
      this.y + PLAYER_SIZE*0.6,
      PLAYER_SIZE/2,
      PLAYER_SIZE/3,
      0,
      0,
      Math.PI * 2
    );
    this.ctx.fill();

    // Draw helmet
    this.ctx.fillStyle = '#1565C0';
    this.ctx.beginPath();
    this.ctx.ellipse(
      this.x + PLAYER_SIZE/2,
      this.y + PLAYER_SIZE/4,
      PLAYER_SIZE/3,
      PLAYER_SIZE/4,
      0,
      0,
      Math.PI * 2
    );
    this.ctx.fill();

    // Draw facemask
    this.ctx.strokeStyle = '#333333';
    this.ctx.lineWidth = 2;
    this.ctx.beginPath();
    this.ctx.moveTo(this.x + PLAYER_SIZE/3, this.y + PLAYER_SIZE/4);
    this.ctx.lineTo(this.x + PLAYER_SIZE*2/3, this.y + PLAYER_SIZE/4);
    this.ctx.stroke();

    // Draw arms in tackling position
    this.ctx.strokeStyle = '#1565C0';
    this.ctx.lineWidth = 4;
    this.ctx.beginPath();

    // Left arm (reaching position)
    this.ctx.moveTo(this.x + PLAYER_SIZE/4, this.y + PLAYER_SIZE*0.6);
    this.ctx.lineTo(this.x, this.y + PLAYER_SIZE*0.4);

    // Right arm (reaching position)
    this.ctx.moveTo(this.x + PLAYER_SIZE*3/4, this.y + PLAYER_SIZE*0.6);
    this.ctx.lineTo(this.x + PLAYER_SIZE, this.y + PLAYER_SIZE*0.4);
    this.ctx.stroke();

    // Draw legs in tackling stance
    this.ctx.beginPath();
    // Left leg (bent)
    this.ctx.moveTo(this.x + PLAYER_SIZE/3, this.y + PLAYER_SIZE*0.8);
    this.ctx.lineTo(this.x + PLAYER_SIZE/4, this.y + PLAYER_SIZE);
    this.ctx.lineTo(this.x + PLAYER_SIZE/3, this.y + PLAYER_SIZE*1.2);
    // Right leg (bent)
    this.ctx.moveTo(this.x + PLAYER_SIZE*2/3, this.y + PLAYER_SIZE*0.8);
    this.ctx.lineTo(this.x + PLAYER_SIZE*3/4, this.y + PLAYER_SIZE);
    this.ctx.lineTo(this.x + PLAYER_SIZE*2/3, this.y + PLAYER_SIZE*1.2);
    this.ctx.stroke();

    // Draw jersey number
    this.ctx.fillStyle = 'white';
    this.ctx.font = 'bold 14px Arial';
    this.ctx.textAlign = 'center';
    this.ctx.textBaseline = 'middle';
    this.ctx.fillText(
      this.playerNumber.toString(),
      this.x + PLAYER_SIZE/2,
      this.y + PLAYER_SIZE*0.6
    );

    this.ctx.restore();
  }

  public collidesWith(player: Player) {
    if (this.disabled) return false;

    const playerPos = player.getPosition();
    const dx = playerPos.x - this.x;
    const dy = playerPos.y - this.y;
    const distance = Math.sqrt(dx * dx + dy * dy);

    return distance < PLAYER_SIZE;
  }

  public disable() {
    this.disabled = true;
  }

  public getPosition() {
    return { x: this.x, y: this.y };
  }

  public setPosition(x: number, y: number) {
    this.x = x;
    this.y = y;
  }
}