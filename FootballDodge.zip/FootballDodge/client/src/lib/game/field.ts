import { CANVAS_WIDTH, CANVAS_HEIGHT } from './constants';

export class Field {
  private ctx: CanvasRenderingContext2D;

  constructor(ctx: CanvasRenderingContext2D) {
    this.ctx = ctx;
  }

  private drawYardNumber(yard: number, y: number) {
    this.ctx.save();
    this.ctx.fillStyle = '#ffffff';
    this.ctx.font = 'bold 20px Arial';
    this.ctx.textAlign = 'center';
    this.ctx.textBaseline = 'middle';

    // Draw on both sides of the field
    this.ctx.fillText(yard.toString(), 40, y);
    this.ctx.fillText(yard.toString(), CANVAS_WIDTH - 40, y);
    this.ctx.restore();
  }

  private drawHashMarks(y: number) {
    this.ctx.save();
    this.ctx.strokeStyle = '#ffffff';
    this.ctx.lineWidth = 2;

    // Left hash marks
    this.ctx.beginPath();
    this.ctx.moveTo(CANVAS_WIDTH * 0.25 - 10, y);
    this.ctx.lineTo(CANVAS_WIDTH * 0.25 + 10, y);
    this.ctx.stroke();

    // Right hash marks
    this.ctx.beginPath();
    this.ctx.moveTo(CANVAS_WIDTH * 0.75 - 10, y);
    this.ctx.lineTo(CANVAS_WIDTH * 0.75 + 10, y);
    this.ctx.stroke();

    this.ctx.restore();
  }

  public draw() {
    // Draw grass background
    this.ctx.fillStyle = '#2E7D32'; // Darker grass green
    this.ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Draw yard lines
    this.ctx.strokeStyle = '#ffffff';
    this.ctx.lineWidth = 2;

    const yardSpacing = (CANVAS_HEIGHT - 100) / 10; // Leave room for endzones
    const startY = 50; // Start after endzone

    // Draw horizontal yard lines
    for (let i = 0; i <= 10; i++) {
      const y = startY + (i * yardSpacing);

      // Draw yard line
      this.ctx.beginPath();
      this.ctx.moveTo(0, y);
      this.ctx.lineTo(CANVAS_WIDTH, y);
      this.ctx.stroke();

      // Draw yard numbers and hash marks for each 10-yard section
      if (i < 10) {
        const midY = y + yardSpacing/2;
        let yardNumber;

        // From bottom to middle: 10, 20, 30, 40, 50
        // From middle to top: 40, 30, 20, 10
        if (i < 5) {
          yardNumber = (i + 1) * 10; // 10, 20, 30, 40, 50 from bottom to middle
        } else {
          yardNumber = (9 - i) * 10; // 40, 30, 20, 10 from middle to top
        }

        this.drawYardNumber(yardNumber, midY);
        this.drawHashMarks(midY);
      }
    }

    // Draw endzones
    this.ctx.fillStyle = '#B71C1C'; // Dark red for endzones
    this.ctx.fillRect(0, 0, CANVAS_WIDTH, 50); // Top endzone
    this.ctx.fillRect(0, CANVAS_HEIGHT - 50, CANVAS_WIDTH, 50); // Bottom endzone

    // Draw endzone text
    this.ctx.fillStyle = '#ffffff';
    this.ctx.font = 'bold 28px Arial';
    this.ctx.textAlign = 'center';
    this.ctx.textBaseline = 'middle';

    // Top endzone text (upside down)
    this.ctx.save();
    this.ctx.translate(CANVAS_WIDTH/2, 25);
    this.ctx.rotate(Math.PI);
    this.ctx.fillText('AWAY', 0, 0);
    this.ctx.restore();

    // Bottom endzone text
    this.ctx.fillText('HOME', CANVAS_WIDTH/2, CANVAS_HEIGHT - 25);
  }
}