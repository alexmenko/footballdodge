import { Controls } from './controls';
import { CANVAS_HEIGHT, CANVAS_WIDTH, PLAYER_SIZE } from './constants';

export class Player {
  private x: number = CANVAS_WIDTH / 2;
  private y: number = CANVAS_HEIGHT - PLAYER_SIZE * 2;
  private readonly BASE_SPEED: number = 5; // Make this a constant
  private baseSpeed: number = this.BASE_SPEED;
  private speedMultiplier: number = 1;
  private ctx: CanvasRenderingContext2D;
  private playerNumber: number = 7;
  private hasBall: boolean = false;
  private overpoweredDefenders: number = 0;

  constructor(ctx: CanvasRenderingContext2D) {
    this.ctx = ctx;
  }

  private drawPlayer(color: string) {
    this.ctx.save();

    // Draw body (jersey)
    this.ctx.fillStyle = color;
    this.ctx.beginPath();
    this.ctx.ellipse(
      this.x + PLAYER_SIZE/2,
      this.y + PLAYER_SIZE*0.6,
      PLAYER_SIZE/2,
      PLAYER_SIZE/3,
      0,
      0,
      Math.PI * 2
    );
    this.ctx.fill();

    // Draw helmet
    this.ctx.fillStyle = color;
    this.ctx.beginPath();
    this.ctx.ellipse(
      this.x + PLAYER_SIZE/2,
      this.y + PLAYER_SIZE/4,
      PLAYER_SIZE/3,
      PLAYER_SIZE/4,
      0,
      0,
      Math.PI * 2
    );
    this.ctx.fill();

    // Draw facemask
    this.ctx.strokeStyle = '#333333';
    this.ctx.lineWidth = 2;
    this.ctx.beginPath();
    this.ctx.moveTo(this.x + PLAYER_SIZE/3, this.y + PLAYER_SIZE/4);
    this.ctx.lineTo(this.x + PLAYER_SIZE*2/3, this.y + PLAYER_SIZE/4);
    this.ctx.stroke();

    // Draw arms
    this.ctx.strokeStyle = color;
    this.ctx.lineWidth = 4;
    this.ctx.beginPath();

    // Left arm
    this.ctx.moveTo(this.x + PLAYER_SIZE/4, this.y + PLAYER_SIZE*0.6);
    this.ctx.lineTo(this.x, this.y + PLAYER_SIZE*0.8);

    // Right arm
    this.ctx.moveTo(this.x + PLAYER_SIZE*3/4, this.y + PLAYER_SIZE*0.6);
    this.ctx.lineTo(this.x + PLAYER_SIZE, this.y + PLAYER_SIZE*0.8);
    this.ctx.stroke();

    // Draw legs
    this.ctx.beginPath();
    // Left leg
    this.ctx.moveTo(this.x + PLAYER_SIZE/3, this.y + PLAYER_SIZE*0.8);
    this.ctx.lineTo(this.x + PLAYER_SIZE/4, this.y + PLAYER_SIZE*1.2);
    // Right leg
    this.ctx.moveTo(this.x + PLAYER_SIZE*2/3, this.y + PLAYER_SIZE*0.8);
    this.ctx.lineTo(this.x + PLAYER_SIZE*3/4, this.y + PLAYER_SIZE*1.2);
    this.ctx.stroke();

    // Draw jersey number
    this.ctx.fillStyle = 'white';
    this.ctx.font = 'bold 14px Arial';
    this.ctx.textAlign = 'center';
    this.ctx.textBaseline = 'middle';
    this.ctx.fillText(
      this.playerNumber.toString(),
      this.x + PLAYER_SIZE/2,
      this.y + PLAYER_SIZE*0.6
    );

    // Draw football only if player has the ball
    if (this.hasBall) {
      this.ctx.fillStyle = '#8B4513';
      this.ctx.beginPath();
      this.ctx.ellipse(
        this.x + PLAYER_SIZE/2,
        this.y + PLAYER_SIZE*0.8,
        PLAYER_SIZE/6,
        PLAYER_SIZE/8,
        Math.PI/4,
        0,
        Math.PI * 2
      );
      this.ctx.fill();
    }

    this.ctx.restore();
  }

  public update(controls: Controls) {
    const currentSpeed = this.baseSpeed * this.speedMultiplier;

    if (controls.left) this.x -= currentSpeed;
    if (controls.right) this.x += currentSpeed;
    if (controls.up) this.y -= currentSpeed;
    if (controls.down) this.y += currentSpeed;

    // Keep player in bounds
    this.x = Math.max(0, Math.min(this.x, CANVAS_WIDTH - PLAYER_SIZE));
    this.y = Math.max(0, Math.min(this.y, CANVAS_HEIGHT - PLAYER_SIZE));
  }

  public draw() {
    this.drawPlayer('#FFD700'); // Gold color for offense
  }

  public reset() {
    this.x = CANVAS_WIDTH / 2;
    this.y = CANVAS_HEIGHT - PLAYER_SIZE * 2;
    this.baseSpeed = this.BASE_SPEED; // Reset to original speed
    this.speedMultiplier = 1;
    this.hasBall = false;
    this.overpoweredDefenders = 0;
  }

  public getPosition() {
    return { x: this.x, y: this.y };
  }

  public hasReachedEndzone() {
    return this.y < PLAYER_SIZE;
  }

  public canCatchBall(kickoffPosition: {x: number, y: number}) {
    const dx = this.x + PLAYER_SIZE/2 - kickoffPosition.x;
    const dy = this.y + PLAYER_SIZE/2 - kickoffPosition.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    return distance < 40; // Same as the circle radius
  }

  public setPosition(x: number, y: number) {
    this.x = x;
    this.y = y;
  }

  public catchBall() {
    this.hasBall = true;
  }

  public setSpeedBoost(multiplier: number) {
    this.speedMultiplier = multiplier;
  }

  public getOverpoweredDefenders() {
    return this.overpoweredDefenders;
  }

  public incrementOverpoweredDefenders() {
    this.overpoweredDefenders++;
  }
}